# Multiway-Trade-Builder

Library for constructing multiway trades as Clarity contracts.